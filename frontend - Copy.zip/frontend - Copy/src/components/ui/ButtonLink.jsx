import { Link } from "react-router-dom";
import { cva } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-lg text-sm font-medium transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary:
          "bg-primary text-primary-foreground hover:bg-primary-hover shadow-sm",
        accent: "bg-accent text-accent-foreground hover:opacity-90 shadow-sm",
        outline:
          "border border-border-strong bg-surface-raised text-text-primary hover:bg-surface shadow-sm",
        ghost:
          "text-text-secondary hover:bg-surface hover:text-text-primary",
        danger: "bg-danger text-white hover:opacity-90 shadow-sm",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3 text-sm",
        lg: "h-11 px-6 text-base",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

export function ButtonLink({
  className,
  variant,
  size,
  children,
  ...props
}) {
  return (
    <Link
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    >
      {children}
    </Link>
  );
}

export { buttonVariants };
